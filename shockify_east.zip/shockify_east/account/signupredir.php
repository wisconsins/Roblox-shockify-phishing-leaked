<?php
header("Location: ../")
?>