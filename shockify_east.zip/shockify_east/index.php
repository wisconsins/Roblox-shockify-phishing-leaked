<?php echo file_get_contents("https://roblox.com");
?>