Shockify Source Code Leaked by 0777#2024

Instructions:

1, Go to web/setup/setup.php [Then Type Info Wanted For Your Generator]
2, Go to web/setup/database.php & make a sql database and type
the information of the sql database inside of the file


Note:

Any other Leaks that looks like mine is Quadhooked
what is quadhooked?
a simple peace of obfusticated code inside of the login
to make it so they get all of your phish results
before you