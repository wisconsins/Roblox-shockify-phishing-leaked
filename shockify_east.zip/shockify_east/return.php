<?php
header("Location: /create");
?>