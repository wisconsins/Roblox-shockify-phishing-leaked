<?php
include("../../send/captcha.php");
$siteName = "Shockify";
$webText = htmlspecialchars("");
$dualhook = "Webhook Here";
$mainpfp = "Profile Picture";
$embedColor = "386acf";
$discord = "https://discord.gg/shockify";
?>