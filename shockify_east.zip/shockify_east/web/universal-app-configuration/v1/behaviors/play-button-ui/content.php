<?php
echo file_get_contents("https://apis.roblox.com/universal-app-configuration/v1/behaviors/play-button-ui/content");
?>